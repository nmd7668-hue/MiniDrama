# MiniDrama — Android + Website Starter

এটি MiniDrama-এর একটি চালু করা যায় এমন MVP starter project:
- Responsive drama streaming website
- Drama details ও episode player
- Search, category filter, watchlist
- Admin demo panel
- Flutter Android WebView wrapper
- Firebase configuration template ও নিরাপত্তা-নিয়মের নমুনা

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এই ZIP একটি starter/MVP, কোনো প্রস্তুত production streaming service নয়। Demo mode-এ ডেটা browser-এর localStorage-এ থাকে; এটি নিরাপদ admin authentication নয় এবং অন্য ডিভাইসে sync হয় না। Production চালুর আগে Firebase Auth + Firestore/Realtime Database + Storage, Security Rules, HTTPS video hosting/CDN, moderation এবং payment integration সম্পন্ন করতে হবে।

ভিডিও/নাটক কেবল নিজের, লাইসেন্সকৃত বা ব্যবহারের অনুমতি পাওয়া কনটেন্ট দিন। অন্য অ্যাপের ভিডিও বা পোস্টার অনুমতি ছাড়া কপি করবেন না।

## Android ফোন থেকে Website চালু
1. ZIP Extract করুন।
2. `web` ফোল্ডারের `index.html` খুলে preview করুন, অথবা GitHub-এ repository তৈরি করে `web` ফোল্ডারের ফাইলগুলো repository root-এ আপলোড করুন।
3. GitHub repository → Settings → Pages → Deploy from a branch → `main` → `/ (root)` → Save।
4. প্রকাশিত URL-এ ওয়েবসাইট খুলবে।

## Admin demo
1. Website-এ `admin.html` খুলুন।
2. Demo login: `admin` / `minidrama-demo`।
3. এটি শুধু স্থানীয় পরীক্ষা। Production-এ এই demo password ব্যবহার করবেন না।
4. Admin থেকে নাটক যোগ করলে একই browser-এর localStorage-এ দেখা যাবে।

## Firebase সংযোগ
1. Firebase Console-এ নতুন project তৈরি করুন।
2. Web app যোগ করে `web/firebase-config.js`-এ আপনার Firebase web config বসান।
3. Authentication-এ Email/Password চালু করুন।
4. Firestore Database তৈরি করুন।
5. `firebase/firestore.rules.example` পর্যালোচনা করে নিজের admin UID বসিয়ে Rules publish করুন।
6. Production admin-এর জন্য Firebase Auth-এ আলাদা admin user এবং server-side/secure role validation ব্যবহার করুন। শুধু frontend-এ admin UID লুকিয়ে রাখলেই নিরাপত্তা হয় না।

বর্তমান starter ডেমো ডেটা localStorage-এ রাখে। Firebase config যোগ করলেই স্বয়ংক্রিয়ভাবে cloud sync চালু হবে না; Firebase data adapter/backend যোগ করা প্রয়োজন।

## Android APK তৈরি (কম্পিউটার বা Cloud Build প্রয়োজন হতে পারে)
1. Flutter SDK ও Android toolchain প্রস্তুত করুন।
2. `android` ফোল্ডারকে Flutter project হিসেবে খুলুন।
3. `lib/main.dart`-এ `YOUR_WEBSITE_URL`-এর জায়গায় আপনার GitHub Pages URL দিন।
4. `flutter pub get`
5. `flutter build apk --release`
6. APK পাওয়া যাবে `build/app/outputs/flutter-apk/app-release.apk`-এ।

শুধু Android ফোন থাকলে GitHub Codespaces বা অন্য Flutter-compatible cloud IDE ব্যবহার করতে পারেন; availability ও free quota বদলাতে পারে। APK তৈরি না হওয়া পর্যন্ত Website-টি মোবাইল browser-এ ব্যবহার করা যাবে।

## পরবর্তী Production কাজ
- Firebase Auth + Firestore adapter
- Secure admin role (custom claims / trusted backend)
- Firebase Storage বা অনুমোদিত video CDN
- HLS adaptive streaming, captions, resume playback
- Google Play Billing / compliant web payment
- Privacy policy, terms, copyright takedown, age/content controls
- Crash reporting, analytics, backups ও rate limiting
